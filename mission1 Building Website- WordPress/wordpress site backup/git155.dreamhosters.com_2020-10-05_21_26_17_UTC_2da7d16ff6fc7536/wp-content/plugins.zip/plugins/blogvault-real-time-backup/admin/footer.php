<footer>
	<div style="background: #45b3e0; margin-top: 20px; padding-top:10px;">
		<div style="width: 850px; margin: 0 auto;">
			<span class="footer-logo" style="color: #FFF; padding: 10px; display: inline-block; font-weight: bold; font-size: 28px; margin-top: 26px; float: left;"> Trusted By </span>
			<span class="footer-logo"><img src="<?php echo plugins_url("/../img/adobe-logo.png", __FILE__); ?>" style="height: 36px; margin-left: 70px;"/></span>
			<span class="footer-logo"><img src="<?php echo plugins_url("/../img/intel-logo.png", __FILE__); ?>" style="height: 38px;" /></span>
			<span class="footer-logo"><img src="<?php echo plugins_url("/../img/wp-site-care-logo.png", __FILE__); ?>" style="height: 32px;" /></span>
			<span class="footer-logo"><img src="<?php echo plugins_url("/../img/valet-logo.png", __FILE__); ?>" style="height: 42px;" /></span>
			<span><img src="<?php echo plugins_url("/../img/yoast-logo.png", __FILE__); ?>" style="height: 32px;" /></span>
		</div>
	</div>
	<div style="background: #45b3e0;">
		<div style="width: 850px; margin: 0 auto;">
			<span class="footer-logo"><img src="<?php echo plugins_url("/../img/cloudways-logo.png", __FILE__); ?>" style="height: 48px; margin-bottom: 10px;" /></span>
			<span class="footer-logo"><img src="<?php echo plugins_url("/../img/wp-engine-logo.png", __FILE__); ?>"/></span>
			<span class="footer-logo"><img src="<?php echo plugins_url("/../img/liquid-web.png", __FILE__); ?>" /></span>
			<span><img src="<?php echo plugins_url("/../img/pressable-logo.png", __FILE__); ?>" /></span>
		</div>
	</div>
</footer>