=== Editor Full Width Gutenberg ===
Contributors: jackalpret
Plugin Name: Editor Full Width Gutenberg
Plugin URI: https://ardid.com.ar/full-width-editor-gutenberg/
Tags: editor, width, gutenberg, blocks, page builder, editor width
Author URI: https://ardid.com.ar/
Author: Anibal Ardid
Requires at least: 4.9.8
Tested up to: 5.5.0
Requires PHP: 5.6.0	
Stable tag: 1.0.5
Version: 1.0.5

This plugin adds custom css to change the default width of the Gutenberg editor to fullsize width.	

== Description ==

This plugin adds custom css to change the default width of the Gutenberg editor to fullsize width.

== Installation ==

Only Upload and Activate plugin

== SCREENSHOTS ==

1. Plugin not installed or disabled
2. Plugin installed and activated

