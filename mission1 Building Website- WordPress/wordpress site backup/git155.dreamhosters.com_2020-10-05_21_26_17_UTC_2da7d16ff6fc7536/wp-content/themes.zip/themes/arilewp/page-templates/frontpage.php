<?php
/**
 * Template Name: Frontpage
 *
 * Displays the Home page.
 *
 * @package arilewp
 */
?>

<?php

get_header(); 

do_action( 'arileextra_arilewp_frontpage', false);
	
?>
<?php get_footer(); ?>
