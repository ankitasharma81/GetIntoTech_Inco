<?php get_header(); ?>
<main id="content" class="content-woocommerce" role="main">
<?php woocommerce_content(); ?>
</main>
<?php get_footer(); ?>