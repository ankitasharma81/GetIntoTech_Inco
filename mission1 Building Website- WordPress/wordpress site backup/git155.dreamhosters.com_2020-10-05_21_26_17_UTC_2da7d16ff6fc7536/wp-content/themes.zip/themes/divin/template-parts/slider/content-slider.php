<?php
/**
 * The template used for displaying slider
 *
 * @package Divin
 */
?>

<?php
/**
 * divin_slider hook
 * @hooked divin_featured_slider - 10
 */
do_action( 'divin_slider' );
