<?php
/**
 * The template used for displaying credits
 *
 * @package Divin
 */
?>

<?php
/**
 * divin_credits hook
 * @hooked divin_footer_content - 10
 */
do_action( 'divin_credits' );
