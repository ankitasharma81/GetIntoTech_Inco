<?php
/*
 * plan section
 */

if ( has_action( 'mp_emmet_section_plan' ) ) {
	do_action( 'mp_emmet_section_plan' );
}