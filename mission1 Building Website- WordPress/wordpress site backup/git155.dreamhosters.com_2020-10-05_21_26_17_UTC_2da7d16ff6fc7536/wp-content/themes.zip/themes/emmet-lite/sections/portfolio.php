<?php
/*
 * portfolio section
 */

if (has_action('mp_emmet_section_portfolio')) {
    do_action('mp_emmet_section_portfolio');
}