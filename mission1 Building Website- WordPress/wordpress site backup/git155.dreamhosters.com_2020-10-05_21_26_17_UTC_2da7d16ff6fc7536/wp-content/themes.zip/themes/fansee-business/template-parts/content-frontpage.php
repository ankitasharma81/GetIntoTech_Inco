<div class="container">
	<div class="fansee-business-front-page-wrapper">
		<?php the_content(); ?>
	</div>
</div>